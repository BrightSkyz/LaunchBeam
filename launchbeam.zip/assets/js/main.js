document.getElementById('version').innerText = process.env.npm_package_version;
